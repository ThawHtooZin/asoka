@extends('adminlte::page')

@section('content_header')
@endsection

@section('content')
    <h1 class="text-2xl">Dashboard For Analysis</h1>
@endsection
